package uz.gita.dictionary1.presentation.dialogs.details

import uz.gita.dictionary1.domain.AppRepository
import uz.gita.dictionary1.domain.AppRepositoryImpl

class DetailsModel : DetailsContract.Model {
    private val repository: AppRepository = AppRepositoryImpl.getInstance()

    override fun getWordById(id : Long) = repository.getWordById(id)

}