package uz.gita.dictionary1.presentation.dialogs.details

import uz.gita.dictionary1.data.sources.entity.WordEntity

interface DetailsContract {
    interface Model {
        fun getWordById(id: Long): WordEntity
    }

    interface View {
        fun showDetails(wordEntity: WordEntity)
    }

    interface Presenter {
        fun loadView(id: Long)
    }
}