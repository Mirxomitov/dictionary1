package uz.gita.dictionary1.data.model

data class WordData(
    val english: String,
    val type: String,
    val transcript: String,
    val uzbek: String,
    val isFavourite : Long
)