package uz.gita.dictionary1.uitls

import android.graphics.Color
import android.text.SpannableString
import android.text.style.ForegroundColorSpan

fun String.createSpannable(query: String): SpannableString {
    val spannable = SpannableString(this)
    val startPos = this.indexOf(query)
    val endPos = startPos + query.length
    if (startPos < 0 || endPos > this.length)
        return spannable
    spannable.setSpan(
        ForegroundColorSpan(Color.parseColor("#1C2CC9")),
        startPos,
        endPos,
        SpannableString.SPAN_EXCLUSIVE_INCLUSIVE,
    )

    return spannable
}