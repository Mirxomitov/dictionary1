package uz.gita.dictionary1.presentation.dialogs.details

import java.util.concurrent.Executors

class DetailsPresenter(private val view: DetailsContract.View) : DetailsContract.Presenter {
    private val model: DetailsContract.Model = DetailsModel()
    private val executor = Executors.newSingleThreadExecutor()
    override fun loadView(id : Long) {
        executor.execute {
            view.showDetails(model.getWordById(id))
        }
    }
}